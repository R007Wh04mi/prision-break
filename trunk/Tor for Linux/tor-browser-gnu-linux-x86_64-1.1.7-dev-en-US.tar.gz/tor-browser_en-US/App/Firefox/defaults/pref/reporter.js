// Make sure there are trailing slashes!
pref("extensions.reporter.privacyURL", "http://reporter.mozilla.org/privacy/");
pref("extensions.reporter.serviceURL", "http://reporter.mozilla.org/service/0.3/");
