//@line 2 "/build/mozilla-1.9.2/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
