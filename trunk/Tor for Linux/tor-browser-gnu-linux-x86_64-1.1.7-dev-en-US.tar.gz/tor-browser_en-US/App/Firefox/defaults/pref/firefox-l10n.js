//@line 36 "/build/mozilla-1.9.2/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/build/mozilla-1.9.2/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
