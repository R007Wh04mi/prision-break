#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Based on GAppProxy by Du XiaoGang dugang@188.com
# Some idea from GAppProxy2 by fcicq@fcicq.net
# thx them

__author__ = 'base64.decodestring("d3d3LmVodXN0QGdtYWlsLmNvbQ==")'
__version__ = '0.3.0'

import zlib, urlparse, logging, time, re, struct, itertools
from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.api import urlfetch, memcache
from google.appengine.runtime import apiproxy_errors

def _unquote_data(s):
    unquote_map = {'0':'\x10', '1':'=', '2':'&'}
    res = s.split('\x10')
    for i in xrange(1, len(res)):
        item = res[i]
        try:
            res[i] = unquote_map[item[0]] + item[1:]
        except KeyError:
            res[i] = '\x10' + item
    return ''.join(res)

def decode_data(qs, keep_blank_values=False, strict_parsing=False):
    pairs = qs.split('&')
    dic = {}
    for name_value in pairs:
        if not name_value and not strict_parsing:
            continue
        nv = name_value.split('=', 1)
        if len(nv) != 2:
            if strict_parsing:
                raise ValueError, "bad query field: %r" % (name_value,)
            if keep_blank_values:
                nv.append('')
            else:
                continue
        if len(nv[1]) or keep_blank_values:
            dic[_unquote_data(nv[0])] = _unquote_data(nv[1])
    return dic

def _quote_data(s):
    return str(s).replace('\x10', '\x100').replace('=','\x101').replace('&','\x102')

def encode_data(dic):
    res = []
    for k,v in dic.iteritems():
        res.append('%s=%s' % (_quote_data(k), _quote_data(v)))
    return '&'.join(res)

def _xor(data, key):
    key = [ord(i) for i in key]
    data = [ord(d)^k for d,k in itertools.izip(data, itertools.cycle(key))]
    return ''.join(map(chr, data))
xor = lambda data, key: key and _xor(data, key) or data

class MainHandler(webapp.RequestHandler):
    Site_Key = ''
    FRS_Headers = ('', 'content-length', 'keep-alive', 'host', 'vary', 'via', 'x-forwarded-for',
                  'proxy-authorization', 'proxy-connection', 'upgrade')
    FRP_Headers = ('', 'x-google-cache-control', 'via')
    Fetch_Max = 3
    Cache_Timeout = 86400  # 3600 * 24 * 1, set 0 for don't cache
    Cache_Max = 512000  # 512 * 1000
    Deadline = (10, 15)

    def sendResponse(self, status_code, headers, content='', method='', url=''):
        self.response.headers['Content-Type'] = 'application/octet-stream'
        if headers is None: # Cache hits
            logging.debug('Memcache hits: "%s %s" %d %d' % (method, url, status_code, len(content)))
            return self.response.out.write(content)
        isHtml = headers.get('content-type', '').find('text/html') >= 0
        use_cache = False
        if method in ('HEAD', 'GET') and status_code==200 and not isHtml and len(content)<=MainHandler.Cache_Max \
            and MainHandler.Cache_Timeout and headers.get('pragma', '').find('no-cache') < 0 \
            and 'set-cookie' not in headers and headers.get('cache-control', '').find('no-cache') < 0:
            t = time.gmtime(time.time() + MainHandler.Cache_Timeout)
            headers['x-cache'] = 'HIT from WallProxy'
            headers['expires'] = time.strftime('%a, %d %b %Y %H:%M:%S GMT', t)
            headers['cache-control'] = 'public, max-age=%d' % MainHandler.Cache_Timeout
            headers['last-modified'] = time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime())
            use_cache = True
        headers = encode_data(headers)
        raw_data = '%s%s%s' % (struct.pack('>3I', status_code, len(headers), len(content)), headers, content)
        if status_code == 206 and not isHtml:
            data = '0' + raw_data
        else:
            data = zlib.compress(raw_data)
            data = len(raw_data) > len(data) and '1'+data or '0'+raw_data
        data = xor(data, MainHandler.Site_Key)
        if use_cache and not memcache.add(url, data, MainHandler.Cache_Timeout, namespace='wallproxy'):
            logging.warning('Memcache set %s failed' % url)
        if status_code == 555:
            logging.warning('Response: "%s %s" %s' % (method, url, content))
        else:
            logging.debug('Response: "%s %s" %d %d/%d/%d' % (method, url, status_code,
                len(content), len(raw_data), len(data)))
        return self.response.out.write(data)

    def sendNotify(self, status_code, content, method='', url='', fullContent=False):
        if not fullContent and status_code!=555:
            content = '<h2>Fetch Server Info</h2><hr noshade="noshade"><p>Code: %d</p>' \
                      '<p>Message: %s</p>' % (status_code, content)
        headers = {'server':'WallProxy/0.3', 'content-type':'text/html', 'content-length':len(content)}
        self.sendResponse(status_code, headers, content, method, url)

    def post(self):
        try:
            request = xor(self.request.body, MainHandler.Site_Key)
            request = decode_data(zlib.decompress(request))
        except:
            return self.sendNotify(555, 'Invalid Content or Site_Key')

        method = request.get('method', 'GET')
        if not hasattr(urlfetch, method):
            return self.sendNotify(555, 'Invalid Method', method)
        fetch_method = getattr(urlfetch, method)

        url = request.get('url', '')
        url_parts = urlparse.urlparse(url)
        if url_parts[0] not in ('http', 'https'):
            return self.sendNotify(555, 'Unsupported Scheme', method, url)

        if url_parts[1].lower() == 'wallproxy':
            if url_parts[2] == '/cache':
                return self.sendNotify(200, '<h2>Memcache Status</h2><hr noshade="noshade"><p>%s</p>' \
                        % memcache.get_stats(), method, url, True)
            elif url_parts[2] == '/cache/reset' and memcache.flush_all():
                return self.sendNotify(200, 'Memcache Reseted', method, url)
            else:
                return self.sendNotify(200, '<h2>Welcome!</h2><hr noshade="noshade">'\
                    '<p>WallProxy is running.</p>', method, url, True)

        payload = request.get('payload')
        deadline = MainHandler.Deadline[payload and 1 or 0]
        cache_content = None
        if MainHandler.Cache_Timeout and method in ('HEAD', 'GET'):
            cache_content = memcache.get(url, namespace='wallproxy')

        fetch_range = 'bytes=0-%d' % (MainHandler.Cache_Max - 1)
        headers = {}
        for line in request.get('headers', '').split('\n'):
            if ':' not in line:
                continue
            key, value = map(str.strip, line.split(':', 1))
            if key.lower() in MainHandler.FRS_Headers:
                continue
            if key.lower()=='if-modified-since' and cache_content:
                return self.sendResponse(304, {'x-cache':'HIT from WallProxy'}, '', method, url)
            if key.lower() == 'range':
                m = re.search(r'(\d+)?-(\d+)?', value)
                if not m: continue
                m = [u and int(u) for u in m.groups()]
                if m[0] is None and m[1] is None: continue
                if m[0] is None:
                    if m[1] > MainHandler.Cache_Max:
                        m[1] = 1023
                elif m[1] is None or m[1]-m[0]+1 > MainHandler.Cache_Max:
                    m[1] = MainHandler.Cache_Max - 1 + m[0]
                fetch_range = ('bytes=%s-%s' % (m[0], m[1])).replace('None', '')
            headers[key] = value
        headers['Connection'] = 'close'
        if cache_content:
            return self.sendResponse(200, None, cache_content, method, url)

        for i in range(MainHandler.Fetch_Max):
            try:
                response = urlfetch.fetch(url, payload, fetch_method, headers, False, False, deadline)
                break
            except apiproxy_errors.OverQuotaError, e:
                time.sleep(1)
            except urlfetch.InvalidURLError, e:
                return self.sendNotify(555, 'Invalid URL: %s' % e, method, url)
            except urlfetch.ResponseTooLargeError, e:
                if method == 'GET':
                    deadline = MainHandler.Deadline[1]
                    headers['Range'] = fetch_range
                else:
                    return self.sendNotify(555, 'Response Too Large: %s' % e, method, url)
            except Exception, e:
                if (i==1 or i==MainHandler.Fetch_Max-2) and method=='GET':
                    deadline = MainHandler.Deadline[1]
                    headers['Range'] = fetch_range
        else:
            return self.sendNotify(555, 'Urlfetch error: %s' % e, method, url)

        for k in MainHandler.FRP_Headers:
            if k in response.headers:
                del response.headers[k]
        if 'set-cookie' in response.headers:
            scs = response.headers['set-cookie'].split(', ')
            cookies = []
            i = -1
            for sc in scs:
                if re.match(r'[^ =]+ ', sc):
                    try:
                        cookies[i] += ', '+sc
                    except:
                        pass
                else:
                    cookies.append(sc)
                    i += 1
            response.headers['set-cookie'] = '\r\nSet-Cookie: '.join(cookies)
        response.headers['connection'] = 'close'
        return self.sendResponse(response.status_code, response.headers, response.content, method, url)

    def get(self):
        self.redirect('http://twitter.com/hexieshe')

def main():
    application = webapp.WSGIApplication([(r'/.*', MainHandler)], debug=True)
    run_wsgi_app(application)

if __name__ == '__main__':
    main()