概述

    * 用过GAppProxy，感觉还不错。 

    * 不过GAppProxy只支持80和443端口（其他端口网站无法代理），只支持HEAD、GET、POST方法（GAE支持的PUT、DELETE没被支持），不能上传二进制文件如图片（Twitter头像无法更新），不能断点续传（大文件下载一半被中断后需要重新下载），只能架在GAE上（GAE的 DELETE方法不完整，因而从Twitter的List中删除某人是用基于GAE的代理无法实现的)，HTTPS会弹出证书无效的警告，也不节约流量和 API调用。 

    * 自己动手，解决问题。基于GAppProxy，旨在解决以上不足的WallProxy因此产生。WallProxy支持更多端口，服务端有GAE版和PHP版。客户端可以同时设置多个服务端，推荐的设置是大流量快速度的 GAE作首选，随便找个可以令WallProxy运行的免费PHP空间作备选以弥补GAE的DELETE缺陷。WallProxy还改进了上传、下载使得支持上传文件（包括二进制文件）、断点续传、更稳定、更节约流量和API调用。同时还支持生成根证书并签名子证书，将生成的根证书 ca.crt导入到浏览器根证书机构后即可不再弹出证书无效的警告；支持类PAC代理规则并可中转其他代理，为提供了代理设置但不提供代理选择的程序提供智能代理选择功能。 

使用方法

    * 试用：WallProxy提供了两个试用账号，普通Windows用户下载Windows打包后解压运行local目录下的proxy.exe或WallProxy.exe；安装有Python的Windows/Linux用户下载源码打包后解压运行local目录下的proxy.py（Windows用于还需安装OpenSSL包）。修改浏览器代理为127.0.0.1:8086或通过代理扩展设置127.0.0.1:8086为代理（使用了代理扩展的话，建议在配置文件 proxy.conf中“AUTOPROXY_LIST = ”这行前面加一个#注释掉该行以加快代理选择速度）。打开http://twitter.com查看是否成功。
    * 搭建自己的服务端：终究用自己的服务端会更好，建议搭建自己的服务端。GAE版修改gae_server/app.yaml中your-gae-id后上传 gae_server文件夹（如何上传，也可使用SDUpload update gae_server上传），每个Google账户可创建10个GAE服务端；PHP版上传php_server文件夹下fetch.php到PHP空间 www根目录。所得服务端地址为http://你的域名/fetch.php，将此地址修改到配置文件中即可。
    * WallProxy使用了memcache缓存来节约流量和API调用（thx fcicq）,可以打开http://wallproxy/cache查看缓存情况，或者http://wallproxy/cache/reset清除缓存。
    * 在GAE的Log查看界面可以看到每次访问的url/响应原始流量/传输流量。 

软件用途

    * 访问无法访问的网站/网页，加速访问慢的网站/网页。 

    假设example.com和www.example.org/load/无法访问： 

   1. 上传WallProxy服务端到GAE空间，假设上传后地址为 http://server.appspot.com/fetch.php
   2. 如下所示修改配置文件proxy.conf：

      LISTEN_ADDR = ('127.0.0.1', 8086)
      GAE_PROXY = [{
          'url': 'http://server.appspot.com/fetch.php',
          'key': '',
          'proxy': {},
      }]
      DIRECT_PROXY = [{}]
      def FindProxyForURL(remote, url, method, headers):
          scheme, host, port = parseURL(url)
          if host == 'wallproxy':
              return GAE_PROXY
          # 对example.com的所有子域使用代理
          if dnsDomainIs(host, 'example.com'):
              return goWallProxy(method, port, headers)
          # 对www.example.org/load/使用代理
          if re.search(r'www\.example\.org/load/', url):
              return goWallProxy(method, port, headers)
          # 其他请求不使用代理
          return DIRECT_PROXY[0]
      def goWallProxy(method, port, headers):
          # GAE只支持GET、HEAD、PUT、POST、DELETE方法
          if method not in ('GET', 'HEAD', 'PUT', 'POST', 'DELETE'):
              return (405, 'Local proxy error, Method not allowed')
          # GAE的DELETE方法有缺陷、不支持上传大于1M，所以我们用PHP弥补
          if method=='DELETE' or int(headers.get('content-length', 0))>0x100000:
              return PHP_PROXY
          # GAE只支持以下端口，余下的用PHP弥补
          if port is None or (port >= 80 and port <= 90) or\
              (port >= 440 and port <= 450) or port >= 1024:
              return GAE_PROXY
          return PHP_PROXY

    * 为提供了代理设置但不提供代理选择的程序提供智能选择代理的功能。 

    例如教育网环境下Ubuntu源的配置，为求快设置了上交等教育网源、求新设置了PPA源，然而教育网直连PPA源速度太慢，虽然apt提供了代理设置功能，却似乎只能一刀切，要么所有源都使用代理，要么都不使用。很显然我们希望能够自动对教育网源直接连接，对PPA源使用代理。如下配置WallProxy即可实现(假设 PPA代理为1.1.1.1:80)：

    LISTEN_ADDR = ('127.0.0.1', 8086)
    DIRECT_PROXY = [{}, {'http':'1.1.1.1:80'}]
    def FindProxyForURL(remote, url, method, headers):
        scheme, host, port = parseURL(url)
        # 对launchpad.net的所有子域使用代理
        if dnsDomainIs(host, 'launchpad.net'):
            return DIRECT_PROXY[1]
        # 其他请求不使用代理
        return DIRECT_PROXY[0]

    * 实现共享上网。 

    例如某单位以如下方式上网：为员工分配一个IP和一个代理服务器的用户名密码，只有当IP与用户名密码匹配，员工才能通过指定的代理服务器上网。某办公室有3名员工，却只分配了1个IP和账号，当其中一名员工使用该IP和账号时，另外两人必须等待。 

   1. 其实第一个人使用WallProxy如下配置，另两个人将代理设为分配的IP则可实现都能上网。

      LISTEN_ADDR = ('', 8086)
      # 假设代理服务器是192.168.0.254:8080，分配的用户名是11111，密码是22222
      DIRECT_PROXY = [{'http':'11111:22222@192.168.0.254:8080'}]
      def FindProxyForURL(remote, url, method, headers):
          return DIRECT_PROXY[0]

   2. 不过隔壁办公室的人居然在偷偷使用这个代理，能否为代理加上密码呢？当然可以，修改一下即可：

      LISTEN_ADDR = ('', 8086)
      # 设置用户名密码为123456、123456
      USER_PWD = ['123456:123456']
      import base64
      USER_PWD = ['Basic '+base64.b64encode(i) for i in USER_PWD]
      del base64
      DIRECT_PROXY = [{'http':'11111:22222@192.168.0.254:8080'}]
      def FindProxyForURL(remote, url, method, headers):
          # 对非本机开启密码
          if remote != '127.0.0.1':
              auth = headers.get('proxy-authorization')
              if auth != USER_PWD[0]:
                  return (407, None, 'Proxy-Authenticate: Basic Realm="WallProxy Authenticate"\r\n\r\n')
          return DIRECT_PROXY[0]

   3. 只有一个密码啊，能不能像单位分配的账号那样一个IP对应一个用户名密码呢？当然可以，再修改一下：

      LISTEN_ADDR = ('', 8086)
      # 设置三个账号
      USER_PWD = ['123456:123456', '223456:654322', '32548:54554']
      import base64
      USER_PWD = ['Basic '+base64.b64encode(i) for i in USER_PWD]
      del base64
      DIRECT_PROXY = [{'http':'11111:22222@192.168.0.254:8080'}]
      def FindProxyForURL(remote, url, method, headers):
          # 对非本机开启密码
          if remote != '127.0.0.1':
              auth = headers.get('proxy-authorization')
              bAuth = False
              # 192.168.1.1使用第一个账号，192.168.1.2使用第二个账号……
              if (remote=='192.168.1.1' and auth==USER_PWD[0]) or\
                 (remote=='192.168.1.2' and auth==USER_PWD[1]) or\
                 (remote=='192.168.1.3' and auth==USER_PWD[2]):
                  bAuth = True
              if not bAuth:
                  return (407, None, 'Proxy-Authenticate: Basic Realm="WallProxy Authenticate"\r\n\r\n')
          return DIRECT_PROXY[0]

   4. 用密码太麻烦了，能不能直接搞个IP黑名单或白名单呢？因为Python的灵活，当然可以：

      LISTEN_ADDR = ('', 8086)
      # 设置IP白名单
      ALLOW_IP = ('127.0.0.1', '192.168.1.1', '192.168.1.2', '192.168.1.3')
      DIRECT_PROXY = [{'http':'11111:22222@192.168.0.254:8080'}]
      def FindProxyForURL(remote, url, method, headers):
          # 如果IP不在白名单中，就拒绝代理
          if remote not in ALLOW_IP:
              return (403,)
          return DIRECT_PROXY[0]

配置规则

    * 书写应符合Python语法，建议在原始配置文件基础上修改，以免因缩进等原因导致出错 

    * LISTEN_ADDR：设置代理的ip和端口。有3种设置形式(假定本机IP为 192.168.0.1)： 

   1. LISTEN_ADDR = ('127.0.0.1', 8086) 只有本机可通过127.0.0.1:8086地址使用WallProxy代理
   2. LISTEN_ADDR = ('', 8086) 本机可通过127.0.0.1:8086或192.168.0.1:8086地址使用WallProxy代理，其他人可通过192.168.0.1:8086地址使用WallProxy代理
   3. LISTEN_ADDR = ('192.168.0.1', 8086) 本机和其他人都能通过192.168.0.1:8086地址使用WallProxy代理 

    * GAE_PROXY、PHP_PROXY：设置WallProxy的服务端信息 

   1. WallProxy的服务端有GAE和PHP两个版本，强烈建议架设自己的服务端(推荐GAE服务端)
   2. PHP服务端用于弥补GAE的不足，如果你没有自己的PHP版，建议保持默认PHP_PROXY不变
   3. 每一个服务端需要设置3个信息：url服务端的地址 key用于异或加密的密钥(可为空值) proxy用于连接服务端的代理。其中url、key是字符串；proxy规则与urllib2代理规则相同，例如 {'http':'www.google.cn:80'}、{'http':'user:pwd@192.168.1.1:8086'}。 如果proxy设置为{}，代表不使用代理，如果设置为None(不建议)，会使用系统代理
   4. WallProxy支持同时设置多个GAE_PROXY和PHP_PROXY，会随机选择以达到负载均衡，如果需要改变代理调用概率，可将某些代理多设置几次
   5. 设置举例：

      GAE_PROXY = [{
          'url': 'http://server1.appspot.com/fetch.php',
          'key': '123\0x01456\0x024789\0x030',
          'proxy': {'http': 'www.google.cn:80'},
      },{
          'url': 'http://server2.appspot.com/index.php',
          'key': '',
          'proxy': {'http': 'ipv6.google.com:80'},
      }]
      GAE_PROXY = [GAE_PROXY[0]]*4 + GAE_PROXY[1] #第1个与第2个调用概率比为4:1

      PHP_PROXY = [{
          'url': 'http://server.example.com/fetch.php',
          'key': '',
          'proxy': {},
      }]

    * DIRECT_PROXY：设置不通过WallProxy服务端，直接访问的代理 

   1. 规则与GAE_PROXY中proxy规则相同，值可以是任意的代理
   2. 建议第一个值是{}，如果设置了多个值，则需要适当修改FindProxyForURL函数以生效
   3. 设置举例：

      DIRECT_PROXY = [{},{'http':'user:pwd@10.1.10.1:8086'},{'http':'127.0.0.1:8000'}]

    * AUTOPROXY_LIST：设置AUTOPROXY LIST的地址(支持设置多个，且可以是本地文件及未加密的文件) 

   1. 默认是http://autoproxy-gfwlist.googlecode.com/svn/trunk/gfwlist.txt
   2. 此项设置主要是为了实现在需要使用代理的时候才使用代理，既加快速度，也节约流量
   3. 如果已经通过AutoProxy等代理扩展实现了代理选择，建议在该行前加#以加快代理选择 

    * RELOAD：设置每隔多少秒检查是否需要自动重新载入配置（0表示不重新载入） 

    * FindProxyForURL：代理选择函数，调控如何使用上面设置的代理(应符合 Python语法) 

   1. 参数remote, url, method, headers依次代表访问者IP、访问url、方法、http头
   2. scheme, host, port = parseURL(url) 从url中提取协议、域名、端口
   3. inAutoProxy(url) 该url是否处于AUTOPROXY LIST中，是返回True，不是返回False
   4. dnsDomainIs(host, domain) host是否是domain的子域，例如

      dnsDomainIs('example.com', 'example.com') 返回True
      dnsDomainIs('a.example.com', 'example.com') 返回True
      dnsDomainIs('aexample.com', 'example.com') 返回False

   5. re.search(regex, url) 该url是否匹配正则表达式regex，例如re.search(r'^http://example\.com', url)，可认为url='http://example.com/'返回 True；url='https://example.com/' 返回False
   6. 可以直接使用GAE_PROXY或PHP_PROXY或DIRECT_PROXY表示负载均衡的使用一组代理，也可使用GAE_PROXY[0]、PHP_PROXY[1:]、DIRECT_PROXY[0:1] + DIRECT_PROXY[2:]等表示使用其中的一个或一部分
   7. 当某些参数不符合条件时(例如不受欢迎的使用者IP、不支持的http方法)返回一个元组，表示拒绝代理，元组格式为“(状态码, 可选的解释, 可选的http头及正文)”，例如：

      return (403, )
      return (405, 'Local proxy error, Method not allowed')
      return (407, None, 'Proxy-Authenticate: Basic Realm="WallProxy"\r\n\r\n')

    * goWallProxy：FindProxyForURL 的子函数，设置如何选择GAE_PROXY和PHP_PROXY
