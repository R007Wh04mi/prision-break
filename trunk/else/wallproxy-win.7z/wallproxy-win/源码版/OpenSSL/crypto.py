# Copyright (C) AB Strakt 2001-2004, All rights reserved
# Copyright (C) Jean-Paul Calderone 2008-2009, All rights reserved

"""
pyOpenSSL - A simple wrapper around the OpenSSL library
"""

__version__ = '0.10'

def __bootstrap__():
   global __bootstrap__, __loader__, __file__
   import sys, pkg_resources, imp
   __file__ = pkg_resources.resource_filename(__name__,'crypto.pyd')
   __loader__ = None; del __bootstrap__, __loader__
   imp.load_dynamic(__name__,__file__)
__bootstrap__()
